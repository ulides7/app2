//
//  ViewController.swift
//  calc
//
//  Created by Mac12 on 23/09/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var sumar: UISegmentedControl!
    
    @IBOutlet weak var entetr2: UIButton!
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var num2: UITextField!
    @IBOutlet weak var num1: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBOutlet weak var imagen: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Suma(_ sender: UIButton) {
        imagen.image = UIImage(named: "suma")
          
          let firstValue = Double(num1.text!)
          let secondValue = Double(num2.text!)
          
          let outputValue = Double(firstValue! + secondValue!)
          
          result.text = "Respuesta:   \(outputValue)"
        num1.text = ""
        num2.text = ""
          
    }
    
    @IBAction func Resta(_ sender: UIButton) {
        imagen.image = UIImage(named: "resta")
        let firstValue = Double(num1.text!)
        let secondValue = Double(num2.text!)
        
        let outputValue = Double(firstValue! - secondValue!)
        
        result.text = "Respuesta:   \(outputValue)"
        num1.text = ""
        num2.text = ""
        
    }
    
    @IBAction func mult(_ sender: UIButton) {
        imagen.image = UIImage(named: "multiplicacion")
        let firstValue = Double(num1.text!)
        let secondValue = Double(num2.text!)
        
        let outputValue = Double(firstValue! * secondValue!)
        
        result.text = "Respuesta:   \(outputValue)"
        num1.text = ""
        num2.text = ""
    }
    
    @IBAction func div(_ sender: UIButton) {
        imagen.image = UIImage(named: "division")
        let firstValue = Double(num1.text!)
        let secondValue = Double(num2.text!)
        
        let outputValue = Double(firstValue! / secondValue!)
        
        result.text = "Respuesta:   \(outputValue)"
        num1.text = ""
        num2.text = ""
    }
    
    
    @IBAction func menu(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
          
            imagen.image = UIImage(named: "suma")
            let firstValue = Double(num1.text!)
            let secondValue = Double(num2.text!)
            
            let outputValue = Double(firstValue! + secondValue!)
            
            result.text = "Respuesta:   \(outputValue)"
            
            
        }else if sender.selectedSegmentIndex == 1 {
            
            imagen.image = UIImage(named: "resta")
            let firstValue = Double(num1.text!)
            let secondValue = Double(num2.text!)
            
            let outputValue = Double(firstValue! - secondValue!)
            
            result.text = "Respuesta:   \(outputValue)"
            
            
        } else if sender.selectedSegmentIndex == 2 {
            
            imagen.image = UIImage(named: "multiplicacion")
            let firstValue = Double(num1.text!)
            let secondValue = Double(num2.text!)
            
            let outputValue = Double(firstValue! * secondValue!)
            
            result.text = "Respuesta:   \(outputValue)"
            
            
        } else if sender.selectedSegmentIndex == 3{
            
            imagen.image = UIImage(named: "division")
            let firstValue = Double(num1.text!)
            let secondValue = Double(num2.text!)
            
            let outputValue = Double(firstValue! / secondValue!)
            
            result.text = "Respuesta:   \(outputValue)"
            }
            
        }
        
    

   
    
}



