//
//  ViewController.swift
//  operationts2
//
//  Created by Mac6 on 14/09/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var num1: UITextField!
    @IBOutlet weak var num2: UITextField!
    @IBOutlet weak var respuesta: UILabel!
   
    @IBAction func enviar(_ sender: UIButton) {
        mensaje.image = UIImage(named: "images") 
        let firstValue = Double (num1.text!)
        let secondValue = Double (num2.text!)
        
        let output = Double(firstValue!+secondValue!)
        
        respuesta.text = "Respuesta \(output) "
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var mensaje: UIImageView!
    
}

